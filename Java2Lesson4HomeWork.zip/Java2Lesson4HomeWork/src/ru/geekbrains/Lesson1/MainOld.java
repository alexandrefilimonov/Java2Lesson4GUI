package ru.geekbrains.Lesson1;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.*;
import java.lang.String;
import java.lang.Object;
public class MainOld {

    public static void main(String[] args) {
        ShowListOfAnimals();

        PhoneBook book = new PhoneBook();
        PhoneBookEntry e = PhoneBookEntry.add("Petrov", 2342323); book.add(e);
        e = PhoneBookEntry.add("Ivanov", 1244444); book.add(e);
        e = PhoneBookEntry.add("Petrov", 2331112); book.add(e);
        e = PhoneBookEntry.add("Sidorov", 4545555); book.add(e);

        // Print out the Phone Book.
        book.printBook();

        // Execute a search on the phone book.
        if (book.searchNumMatches("Petrov") > 0) {
            System.out.println("\nHere are the entries the matched your search Petrov");
            book.get("Petrov");
        }
        else
            System.out.println("\nSorry, no entries matched your search Petrov.");
// Execute a search on the phone book.

        if (book.searchNumMatches("Ivanov") > 0) {
            System.out.println("\nHere are the entries the matched your search Ivanov.");
            book.get("Ivanov");
        }
        else
            System.out.println("\nSorry, no entries matched your search Ivanov.");

    }

    static void ShowListOfAnimals() {
        String[] aArrayOfAnimals = {"Cat","Dog","Horse","Pig","Dog","Cat","Dog","Sheep","Dog","Goat","Sheep"};
        System.out.print("\nAll animals from the array: ");
        for (int j = 0; j < aArrayOfAnimals.length; j++) {
            if(j != 0) {
                System.out.print(", ");
            }
            System.out.print(aArrayOfAnimals[j]);
        }
        Arrays.sort(aArrayOfAnimals);
        int iQty=1;
        String sAnimal = aArrayOfAnimals[0];
        Map<String, Integer> mapDictionaryOfUniqueWordsOfAnimals = new HashMap<>();
        mapDictionaryOfUniqueWordsOfAnimals.put(sAnimal, 1);

        boolean bFirstUniqueAnimalWasPrinted = false;
        for (int i = 1; i < aArrayOfAnimals.length; i++) {
            String sWord = aArrayOfAnimals[i];
            if(mapDictionaryOfUniqueWordsOfAnimals.containsKey(sWord)) {
                Integer val = (int)mapDictionaryOfUniqueWordsOfAnimals.get(sWord);
                mapDictionaryOfUniqueWordsOfAnimals.put(sWord, val + 1);
            }
            else
                mapDictionaryOfUniqueWordsOfAnimals.put(sWord, 1);
        }

        System.out.print("\n\nThe list of unique names of animals: ");
        for (String name: mapDictionaryOfUniqueWordsOfAnimals.keySet()){
            String key =name.toString();
            String value = mapDictionaryOfUniqueWordsOfAnimals.get(name).toString();
            if (Integer.parseInt(value)==1)
                System.out.print(key+" ");


        }
        System.out.print("\n\nAll repeated animals:\n");
        for (String name: mapDictionaryOfUniqueWordsOfAnimals.keySet()){
            String key =name.toString();
            String value = mapDictionaryOfUniqueWordsOfAnimals.get(name).toString();
            if (Integer.parseInt(value)!=1)
                System.out.println(key+" " + value);
        }
       // mapDictionaryOfUniqueWordsOfAnimals.forEach((key, value) -> System.out.println(key + ":" + value));
    }
}
