package ru.geekbrains.Lesson1;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class FXML_Main extends Application {
    
   @Override
    public void start(Stage stage) throws Exception {
         
        Parent root = FXMLLoader.load(getClass().getResource("JavaFXML.fxml")); 
        Scene scene = new Scene(root);
         
        stage.setScene(scene);
         
        stage.setTitle("Chat Prototype");
        stage.setWidth(650);
        stage.setHeight(400);
         
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
