package ru.geekbrains.Lesson1;
import java.util.*;
import java.io.*;
// collection of phone book entries
public class PhoneBook
{
    //protected Map<String, Entry> book;
    //public void add(Entry e)
    //{
    //    book.put(e.name(), e);
    //}
    //public Entry lookup(String name)
    //{
    //    return book.get(name);
    //}
    private PhoneBookEntry[] book;
    private int cur_entry;

    // Creates an empty PhoneBook object.
    public PhoneBook() {
        book = new PhoneBookEntry[1000];
        cur_entry = 0;
    }

    // Returns true iff the current object is full.
    public boolean full() {
        return (cur_entry == 1000);
    }

    // Adds the entry e into the current object, returning true if the add
    // was done successfully. If false is returned, no entry is added to the
    // current object.
    public boolean add(PhoneBookEntry e) {
        if (cur_entry == 1000) return false;
        book[cur_entry] = e;
        cur_entry++;
        return true;
    }

    // Prints out the entire object.
    public void printBook() {
        System.out.println("\nHere are all the current entries in Phone book:");
        for (int i=0; i<cur_entry; i++)
            System.out.println(i+". "+book[i]);
    }

    // Prints out all entries that have the last name lastname.
    public void get(String lastname) {
        for (int i=0; i<cur_entry; i++)
            if (book[i].sameLastName(lastname))
                System.out.println(i+". "+book[i]);
    }

    // Returns the number of entries with the last name lastname.
    public int searchNumMatches(String lastname) {
        int cnt = 0;
        for (int i=0; i<cur_entry; i++)
            if (book[i].sameLastName(lastname))
                cnt++;
        return cnt;
    }

    // Returns the index of the first entry in the current object with the
    // last name lastname. If no such entry exists, -1 is returned.
    public int getIndex(String lastname) {
        for (int i=0; i<cur_entry; i++)
            if (book[i].sameLastName(lastname))
                return i;
        return -1;
    }
}
